//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� OPPWMJExe.rc ʹ��
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_OPPWMJTYPE                  129
#define IDR_TOOLBAR1                    132
#define ID_ZOOMIN                       32771
#define ZOOM_IN                         32772
#define ZOOM_FULL                       32773
#define ZOOM_CLIP                       32774
#define ZOOM_MOVE                       32775
#define ID_BUTTON32776                  32776
#define ZOOM_TRANS                      32777

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32778
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
